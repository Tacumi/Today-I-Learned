-- START:module
module AwesomeDateTest exposing (suite)
-- END:module

-- START:imports
import Expect
import Test exposing (..)
-- END:imports


-- START:suite
suite : Test
suite =
    describe "AwesomeDate" []
-- END:suite
