module Main exposing (main)

import Html exposing (text)


-- START:greeting
greeting : String
greeting =
    "Hello, Static Elm!"
-- END:greeting



-- START:main
main =
    text greeting
-- END:main
