-- START:module
module Main exposing (main)
-- END:module

-- START:import
import Html exposing (text)
-- END:import


-- START:main
main =
    text "Hello, Elm!"
-- END:main
