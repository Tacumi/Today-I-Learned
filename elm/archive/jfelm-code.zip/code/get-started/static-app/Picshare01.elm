-- START:module
module Picshare exposing (main)
-- END:module

-- START:import
import Html exposing (Html, div, text)
-- END:import


-- START:main
main : Html msg
main =
    div [] [ text "Picshare" ]
-- END:main
