AccountMsg accountMsg ->
  case model.page of
      Account accountModel ->
          ...
